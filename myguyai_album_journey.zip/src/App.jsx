
import React, { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Pause, ChevronLeft, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const shirts = [
  { name: "THE GOD VIBE Tee", color: "bg-black", text: "text-white", url: "https://www.etsy.com/listing/your-god-vibe-shirt" },
  { name: "DO RIGHT Tee", color: "bg-white", text: "text-black", url: "https://www.etsy.com/listing/your-do-right-shirt" },
  { name: "CRUCIFY Tee", color: "bg-red-700", text: "text-white", url: "https://www.etsy.com/listing/your-crucify-shirt" },
];

export default function MyGuyAIAlbumJourney() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [entered, setEntered] = useState(false);
  const [shirtIndex, setShirtIndex] = useState(0);
  const audioRef = useRef(null);

  const handleToggle = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleEnter = () => {
    setEntered(true);
  };

  const handleNext = () => {
    setShirtIndex((shirtIndex + 1) % shirts.length);
  };

  const handlePrev = () => {
    setShirtIndex((shirtIndex - 1 + shirts.length) % shirts.length);
  };

  const currentShirt = shirts[shirtIndex];

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-indigo-900 text-white p-4 flex flex-col items-center justify-between">
      <AnimatePresence>
        {!entered ? (
          <motion.div
            key="entry"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, y: -100 }}
            transition={{ duration: 1 }}
            className="flex flex-col items-center space-y-4 mt-16"
          >
            <div className="text-center space-y-2">
              <h1 className="text-3xl font-bold">My Guy AI Album Journey</h1>
              <p className="text-sm text-purple-300">Featuring faith-based streetwear by</p>
              <div className="flex items-center justify-center space-x-6 text-xl font-semibold">
                <span className="text-white">DoRight</span>
                <span className="text-white">Crucify</span>
              </div>
            </div>
            <motion.div
              onClick={handleEnter}
              whileTap={{ scale: 0.95 }}
              className="w-64 h-64 bg-gradient-to-tr from-yellow-400 to-pink-500 rounded-2xl shadow-xl flex items-center justify-center cursor-pointer"
            >
              <span className="text-black text-xl font-bold">Tap to Enter</span>
            </motion.div>
            <p className="text-sm text-purple-200">Put on your headphones and step into the journey</p>
          </motion.div>
        ) : (
          <motion.div
            key="main"
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="flex flex-col items-center space-y-6 w-full"
          >
            <Card className="w-full max-w-sm bg-white text-black rounded-xl shadow-lg">
              <CardContent className="flex flex-col items-center py-4">
                <p className="text-lg font-bold mb-1">Now Playing</p>
                <p className="text-sm text-gray-600 mb-3">The God Vibe</p>
                <motion.div
                  className="flex items-center space-x-4"
                  key={shirtIndex}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                >
                  <Button onClick={handleToggle} variant="outline">
                    {isPlaying ? <Pause /> : <Play />}
                  </Button>
                  <div className={`${currentShirt.color} ${currentShirt.text} px-4 py-1 rounded-full font-semibold`}>
                    {currentShirt.name}
                  </div>
                </motion.div>
                <div className="flex space-x-4 mt-4">
                  <Button onClick={handlePrev} variant="ghost">
                    <ChevronLeft />
                  </Button>
                  <Button onClick={handleNext} variant="ghost">
                    <ChevronRight />
                  </Button>
                </div>
                <a href={currentShirt.url} target="_blank" rel="noopener noreferrer">
                  <Button className="mt-4" variant="secondary">Shop This Look</Button>
                </a>
                <audio ref={audioRef} src="/the_god_vibe.wav" preload="auto" />
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
